#ifndef Utils_h
#define Utils_h

#include <vector>
#include <string>

std::string GetCurrentWorkingDir( void ) {
	char buff[FILENAME_MAX];
	getcwd( buff, FILENAME_MAX );
	std::string current_working_dir(buff);
	return current_working_dir;
};


#endif
