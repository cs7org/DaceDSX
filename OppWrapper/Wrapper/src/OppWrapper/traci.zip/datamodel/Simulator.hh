/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#ifndef SIMULATOR_HH_1406189481__H_
#define SIMULATOR_HH_1406189481__H_


#include <sstream>
#include "boost/any.hpp"
#include "avro/Specific.hh"
#include "avro/Encoder.hh"
#include "avro/Decoder.hh"
#include "Observer.hh"

namespace c {
struct Simulator {
    int32_t ID;
    std::string Type;
    std::string Domain;
    std::string Layer;
    int32_t StepLength;
    std::vector<std::string > Responsibilities;
    std::vector<std::string > Borders;
    std::vector<Observer > Observers;
    Simulator() :
        ID(int32_t()),
        Type(std::string()),
        Domain(std::string()),
        Layer(std::string()),
        StepLength(int32_t()),
        Responsibilities(std::vector<std::string >()),
        Borders(std::vector<std::string >()),
        Observers(std::vector<Observer>())
        { }
};

}
namespace avro {
template<> struct codec_traits<c::Simulator> {
    static void encode(Encoder& e, const c::Simulator& v) {
        avro::encode(e, v.ID);
        avro::encode(e, v.Type);
        avro::encode(e, v.Domain);
        avro::encode(e, v.Layer);
        avro::encode(e, v.StepLength);
        avro::encode(e, v.Responsibilities);
        avro::encode(e, v.Borders);
        avro::encode(e, v.Observers);
    }
    static void decode(Decoder& d, c::Simulator& v) {
        if (avro::ResolvingDecoder *rd =
            dynamic_cast<avro::ResolvingDecoder *>(&d)) {
            const std::vector<size_t> fo = rd->fieldOrder();
            for (std::vector<size_t>::const_iterator it = fo.begin();
                it != fo.end(); ++it) {
                switch (*it) {
                case 0:
                    avro::decode(d, v.ID);
                    break;
                case 1:
                    avro::decode(d, v.Type);
                    break;
                case 2:
                    avro::decode(d, v.Domain);
                    break;
                case 3:
                    avro::decode(d, v.Layer);
                    break;
                case 4:
                    avro::decode(d, v.StepLength);
                    break;
                case 5:
                    avro::decode(d, v.Responsibilities);
                    break;
                case 6:
                    avro::decode(d, v.Borders);
                    break;
                case 7:
                    avro::decode(d, v.Observers);
                    break;
                default:
                    break;
                }
            }
        } else {
            avro::decode(d, v.ID);
            avro::decode(d, v.Type);
            avro::decode(d, v.Domain);
            avro::decode(d, v.Layer);
            avro::decode(d, v.StepLength);
            avro::decode(d, v.Responsibilities);
            avro::decode(d, v.Borders);
            avro::decode(d, v.Observers);
        }
    }
};

}
#endif
