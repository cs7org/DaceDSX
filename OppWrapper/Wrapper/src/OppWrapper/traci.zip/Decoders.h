/*
 * Federate.cpp
 *
 *  Created on: 22.01.2018
 *      Author: guetlein
 */
#ifndef DECODERS_H
#define DECODERS_H

#include <iostream>
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cstdio>
#include <memory>
#include <string>
#include <ctime>
#include <thread>
#include <stdlib.h>
#include <algorithm>

#include <avro/Encoder.hh>
#include <avro/Decoder.hh>
#include <avro/Generic.hh>
#include <avro/Specific.hh>
#include <avro/Exception.hh>
#include <libserdes/serdescpp-avro.h>
#include <libserdes/serdes-avro.h>
#include <libserdes/serdescpp.h>
#include <libserdes/serdes.h>

#include "datamodel/Tag.hh"
#include "datamodel/Tar.hh"
#include "datamodel/Config.hh"
#include "datamodel/Micro.hh"
#include "datamodel/Resp.hh"
#include "datamodel/Scenario.hh"
#include "datamodel/ResourceFile.hh"
#include "datamodel/SyncMsg.hh"
#include "datamodel/RadioMsg11p.hh"


using namespace std;
using namespace std::chrono;


class Decoders {
private:
	static Decoders* inst;
	Decoders();

public:
	static Decoders* getInstance();
	void initSchema(std::vector<std::string> topics);
	std::map<string, Serdes::Schema*> schemas;

	~Decoders(){delete Decoders::inst;};
	Serdes::Avro *serdes;

//	std::vector<char> encodeTAR (std::string id, long time);
//	c::TAG decodeTAG (const std::string &pfx, const void *buf, size_t len);
//	c::TAR decodeTAR (const std::string &pfx, const void *buf, size_t len);
	c::ResourceFile decodeResourceFile (const std::string &pfx, const void *buf, size_t len) ;
	c::SyncMsg decodeSyncMsg (const std::string &pfx, const void *buf, size_t len) ;
	c::Scenario decodeScenario (const std::string &pfx, const void *buf, size_t len) ;
	c::Config decodeConfig (const std::string &pfx, const void *buf, size_t len) ;
	c::Resp decodeResp (const std::string &pfx, const void *buf, size_t len) ;
	c::Micro decodeMicro (const std::string &pfx, const void *buf, size_t len);
	c::RadioMsg11p decodeRadioMsg11p (const std::string &pfx, const void *buf, size_t len);


	std::vector<char> encodeMicro (c::Micro& micro);
	std::vector<char> encodeResourceFile (c::ResourceFile& rf);
	std::vector<char> encodeSyncMsg (string id, string action, long time, std::vector<c::KeyValue> messages);
	std::vector<char> encodeRadioMsg11p (c::RadioMsg11p msg);

};
#endif
