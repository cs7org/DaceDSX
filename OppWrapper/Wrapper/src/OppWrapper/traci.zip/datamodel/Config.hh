/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#ifndef _HOME_GUETLEIN_SVN_GUETLEIN_SUMOFEDERATEWRAPPER_CONFIG_HH_1443995038__H_
#define _HOME_GUETLEIN_SVN_GUETLEIN_SUMOFEDERATEWRAPPER_CONFIG_HH_1443995038__H_


#include <sstream>
#include "boost/any.hpp"
#include "avro/Specific.hh"
#include "avro/Encoder.hh"
#include "avro/Decoder.hh"

namespace c {
struct Config {
    std::string name;
    int32_t start;
    int32_t end;
    int32_t step;
    Config() :
        name(std::string()),
        start(int32_t()),
        end(int32_t()),
        step(int32_t())
        { }
};

}
namespace avro {
template<> struct codec_traits<c::Config> {
    static void encode(Encoder& e, const c::Config& v) {
        avro::encode(e, v.name);
        avro::encode(e, v.start);
        avro::encode(e, v.end);
        avro::encode(e, v.step);
    }
    static void decode(Decoder& d, c::Config& v) {
        if (avro::ResolvingDecoder *rd =
            dynamic_cast<avro::ResolvingDecoder *>(&d)) {
            const std::vector<size_t> fo = rd->fieldOrder();
            for (std::vector<size_t>::const_iterator it = fo.begin();
                it != fo.end(); ++it) {
                switch (*it) {
                case 0:
                    avro::decode(d, v.name);
                    break;
                case 1:
                    avro::decode(d, v.start);
                    break;
                case 2:
                    avro::decode(d, v.end);
                    break;
                case 3:
                    avro::decode(d, v.step);
                    break;
                default:
                    break;
                }
            }
        } else {
            avro::decode(d, v.name);
            avro::decode(d, v.start);
            avro::decode(d, v.end);
            avro::decode(d, v.step);
        }
    }
};

}
#endif
