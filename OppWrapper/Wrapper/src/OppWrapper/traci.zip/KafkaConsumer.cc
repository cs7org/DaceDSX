#include "KafkaConsumer.h"

#include "datamodel/Resp.hh"
#include "datamodel/Config.hh"
#include "datamodel/SyncMsg.hh"
#include "Decoders.h"
#include "Defines.h"

	void KafkaConsumer::subscribe(std::string brokers, std::vector<std::string> topics, KafkaConnection* cb) {

	callback = cb;


    string group_id = "omnet"+callback->scenarioID;
    std::cout << "group id is " << group_id << endl;

	// Construct the configuration
	Configuration config = {
			{ "metadata.broker.list", brokers },
			{ "group.id", group_id },
			// Disable auto commit
			{ "enable.auto.commit", false },
	        { "enable.idempotence", true },
			{ "auto.offset.reset", "earliest"}
	};

	// Create the consumer
	consumer = new Consumer(config);

	// Print the assigned partitions on assignment
	consumer->set_assignment_callback([](const TopicPartitionList& partitions) {
		cout << "Got assigned: " << partitions << endl;
	});

	// Print the revoked partitions on revocation
	consumer->set_revocation_callback([](const TopicPartitionList& partitions) {
		cout << "Got revoked: " << partitions << endl;
	});

	// Subscribe to the topic
	consumer->subscribe(topics);

	cout << "Consuming messages from topic ";
	for (int i = 0; i< topics.size(); i++){
		//		callbacks[topics[i]] = cbs[i];
		cout << topics[i] << ", ";
	}
	cout << endl;
	//

	t1 = std::thread(&KafkaConsumer::listen,this);
}

void KafkaConsumer::listen(){
	cout << "Listener Thread started " << endl;

	// Create a consumer dispatcher
	ConsumerDispatcher dispatcher(*consumer);
	// Stop processing on SIGINT
	//	on_signal = [&]() {
	//		dispatcher.stop();
	//	};
	//	signal(SIGINT, signal_handler);
	// Now run the dispatcher, providing a callback to handle messages, one to handle
	// errors and another one to handle EOF on a partition
	dispatcher.run(
			// Callback executed whenever a new message is consumed
			[&](Message msg) {
		// Print the key (if any)
		std::string key = "";
		std::stringstream keys;
		std::stringstream payloads;
		std::string payload = "";
		if (msg.get_key()) {
			cout << "Received key= " <<msg.get_key() << endl;
			key = msg.get_key();
		}
		if (msg.get_payload()) {
			payload = msg.get_payload();
		}
		if(msg.get_topic() == callback->getTopic(CHANNEL_ORCHESTRATION, TOPIC_SYNCMSG)){
			cout << "received TOPIC_SYNCMSG" << endl;
			if(key == "tag"){
				c::SyncMsg tag = Decoders::getInstance()->decodeSyncMsg("payload", msg.get_handle()->payload ,msg.get_handle()->len);
				if(tag.Action == "grant")
				    callback->handleTopicSyncMsg(key, tag);

			} else {
				cout << "+++++++++++ no key " << key << " in topicTAG" << endl;
			}
		}
        else if(msg.get_topic() == callback->getTopic(CHANNEL_PROVISION, "vehicle.micro")){
            c::Micro m = Decoders::getInstance()->decodeMicro("payload", msg.get_handle()->payload, msg.get_handle()->len);
            callback->handleTopicMicro(key, m);
        }
        else if(msg.get_topic() == callback->getTopic(CHANNEL_INTERACTION, "communication.send")){
            c::RadioMsg11p m = Decoders::getInstance()->decodeRadioMsg11p("payload", msg.get_handle()->payload, msg.get_handle()->len);
            callback->handleTopicSendRadioMsg11p(key, m);
        }

		consumer->commit(msg);
	},
	// Whenever there's an error (other than the EOF soft error)
	[](Error error) {
		cout << "[+] Received error notification: " << error << endl;
	},
	// Whenever EOF is reached on a partition, print this
	[](ConsumerDispatcher::EndOfFile, const TopicPartition& topic_partition) {
		cout << "Reched EOF on partition " << topic_partition << endl;
	}
	);
}
