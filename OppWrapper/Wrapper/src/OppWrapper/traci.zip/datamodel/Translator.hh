/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#ifndef TRANSLATOR_HH_3037032244__H_
#define TRANSLATOR_HH_3037032244__H_


#include <sstream>
#include "boost/any.hpp"
#include "avro/Specific.hh"
#include "avro/Encoder.hh"
#include "avro/Decoder.hh"

namespace c {
struct Translator {
    std::string ID;
    std::string Domain;
    std::string InputLayer;
    std::string OutputLayer;
    std::string CustomParams;
    Translator() :
        ID(std::string()),
        Domain(std::string()),
        InputLayer(std::string()),
        OutputLayer(std::string()),
        CustomParams(std::string())
        { }
};

}
namespace avro {
template<> struct codec_traits<c::Translator> {
    static void encode(Encoder& e, const c::Translator& v) {
        avro::encode(e, v.ID);
        avro::encode(e, v.Domain);
        avro::encode(e, v.InputLayer);
        avro::encode(e, v.OutputLayer);
        avro::encode(e, v.CustomParams);
    }
    static void decode(Decoder& d, c::Translator& v) {
        if (avro::ResolvingDecoder *rd =
            dynamic_cast<avro::ResolvingDecoder *>(&d)) {
            const std::vector<size_t> fo = rd->fieldOrder();
            for (std::vector<size_t>::const_iterator it = fo.begin();
                it != fo.end(); ++it) {
                switch (*it) {
                case 0:
                    avro::decode(d, v.ID);
                    break;
                case 1:
                    avro::decode(d, v.Domain);
                    break;
                case 2:
                    avro::decode(d, v.InputLayer);
                    break;
                case 3:
                    avro::decode(d, v.OutputLayer);
                    break;
                case 4:
                    avro::decode(d, v.CustomParams);
                    break;
                default:
                    break;
                }
            }
        } else {
            avro::decode(d, v.ID);
            avro::decode(d, v.Domain);
            avro::decode(d, v.InputLayer);
            avro::decode(d, v.OutputLayer);
            avro::decode(d, v.CustomParams);
        }
    }
};

}
#endif
