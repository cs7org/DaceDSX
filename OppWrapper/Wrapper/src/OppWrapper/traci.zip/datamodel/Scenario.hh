/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#ifndef SCENARIO_HH_2922236184__H_
#define SCENARIO_HH_2922236184__H_


#include <sstream>
#include "boost/any.hpp"
#include "avro/Specific.hh"
#include "avro/Encoder.hh"
#include "avro/Decoder.hh"
#include "TrafficSimulator.hh"
#include "AdditionalSimulator.hh"
#include "Input.hh"
#include "Translator.hh"

namespace c {
struct Execution {
    int64_t RandomSeed;
    std::string Constraints;
    int64_t Priority;
    int64_t SyncedParticipants;
    Execution() :
        RandomSeed(int64_t()),
        Constraints(std::string()),
        Priority(int64_t()),
        SyncedParticipants(int64_t())
        { }
};

struct Scenario {
    std::string ID;
    std::string RoadMap;
    std::vector<uint8_t> MapFile;
    int64_t SimulationStart;
    int64_t SimulationEnd;
    std::vector<Input> Inputs;
    c::Execution Execution;
    std::vector<TrafficSimulator > TrafficSimulators;
    std::vector<Translator > Translators;
    std::vector<AdditionalSimulator> AdditionalSimulators;
    Scenario() :
        ID(std::string()),
        RoadMap(std::string()),
        MapFile(std::vector<uint8_t>()),
        SimulationStart(int64_t()),
        SimulationEnd(int64_t()),
        Inputs(std::vector<Input >()),
        Execution(c::Execution()),
        TrafficSimulators(std::vector<TrafficSimulator>()),
        Translators(std::vector<Translator>()),
        AdditionalSimulators(std::vector<AdditionalSimulator>())
        { }
};

}
namespace avro {
template<> struct codec_traits<c::Execution> {
    static void encode(Encoder& e, const c::Execution& v) {
        avro::encode(e, v.RandomSeed);
        avro::encode(e, v.Constraints);
        avro::encode(e, v.Priority);
        avro::encode(e, v.SyncedParticipants);
    }
    static void decode(Decoder& d, c::Execution& v) {
        if (avro::ResolvingDecoder *rd =
            dynamic_cast<avro::ResolvingDecoder *>(&d)) {
            const std::vector<size_t> fo = rd->fieldOrder();
            for (std::vector<size_t>::const_iterator it = fo.begin();
                it != fo.end(); ++it) {
                switch (*it) {
                case 0:
                    avro::decode(d, v.RandomSeed);
                    break;
                case 1:
                    avro::decode(d, v.Constraints);
                    break;
                case 2:
                    avro::decode(d, v.Priority);
                    break;
                case 3:
                    avro::decode(d, v.SyncedParticipants);
                    break;
                default:
                    break;
                }
            }
        } else {
            avro::decode(d, v.RandomSeed);
            avro::decode(d, v.Constraints);
            avro::decode(d, v.Priority);
            avro::decode(d, v.SyncedParticipants);
        }
    }
};

template<> struct codec_traits<c::Scenario> {
    static void encode(Encoder& e, const c::Scenario& v) {
        avro::encode(e, v.ID);
        avro::encode(e, v.RoadMap);
        avro::encode(e, v.MapFile);
        avro::encode(e, v.SimulationStart);
        avro::encode(e, v.SimulationEnd);
        avro::encode(e, v.Inputs);
        avro::encode(e, v.Execution);
        avro::encode(e, v.TrafficSimulators);
        avro::encode(e, v.Translators);
        avro::encode(e, v.AdditionalSimulators);
    }
    static void decode(Decoder& d, c::Scenario& v) {
        if (avro::ResolvingDecoder *rd =
            dynamic_cast<avro::ResolvingDecoder *>(&d)) {
            const std::vector<size_t> fo = rd->fieldOrder();
            for (std::vector<size_t>::const_iterator it = fo.begin();
                it != fo.end(); ++it) {
                switch (*it) {
                case 0:
                    avro::decode(d, v.ID);
                    break;
                case 1:
                    avro::decode(d, v.RoadMap);
                    break;
                case 2:
                    avro::decode(d, v.MapFile);
                    break;
                case 3:
                    avro::decode(d, v.SimulationStart);
                    break;
                case 4:
                    avro::decode(d, v.SimulationEnd);
                    break;
                case 5:
                    avro::decode(d, v.Inputs);
                    break;
                case 6:
                    avro::decode(d, v.Execution);
                    break;
                case 7:
                    avro::decode(d, v.TrafficSimulators);
                    break;
                case 8:
                    avro::decode(d, v.Translators);
                    break;
                case 9:
                    avro::decode(d, v.AdditionalSimulators);
                    break;
                default:
                    break;
                }
            }
        } else {
            avro::decode(d, v.ID);
            avro::decode(d, v.RoadMap);
            avro::decode(d, v.MapFile);
            avro::decode(d, v.SimulationStart);
            avro::decode(d, v.SimulationEnd);
            avro::decode(d, v.Inputs);
            avro::decode(d, v.Execution);
            avro::decode(d, v.TrafficSimulators);
            avro::decode(d, v.Translators);
            avro::decode(d, v.AdditionalSimulators);
        }
    }
};

}
#endif
