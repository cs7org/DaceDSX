/*
 * KafkaConnection.cpp
 *
 *  Created on: Mar 16, 2020
 *      Author: guetlein
 */

#ifndef KafkaConnection_H
#define KafkaConnection_H

#include <iostream>
#include <string>
#include "datamodel/Micro.hh"
#include "datamodel/SyncMsg.hh"
#include "datamodel/RadioMsg11p.hh"
#include "Decoders.h"
#include "Defines.h"
#include "KafkaConsumer.h"
#include "KafkaProducer.h"
#include "TraCICoord.h"
#include "TraCICoordinateTransformation.h"
#include "veins/modules/messages/BaseFrame1609_4_m.h"
#include "veins/modules/messages/DemoSafetyMessage_m.h"

class KafkaProducer;
class KafkaConsumer;

class KafkaConnection{

public:
    static KafkaConnection* inst;
    static KafkaConnection* getInstance(std::string);
    static KafkaConnection* getInstance();

    std::string scenarioID = "";
    std::string host = "127.0.0.1:9092";
    std::vector<c::Micro> unreadSubscribtions;
    std::vector<c::RadioMsg11p> unreadsendMsgRequests;

    long kafkaTime = -1;
    KafkaProducer* producer;
    KafkaConsumer* consumer;

    KafkaConnection(std::string s){
        scenarioID = s;
    }

    void init();
    std::string getTopic(std::string channel, std::string topic);
    void join();
    void timeAdvance(long time);
    void handleTopicMicro(std::string key, c::Micro micro);
    void handleTopicSyncMsg(std::string key, c::SyncMsg msg);
    void handleTopicSendRadioMsg11p(std::string key, c::RadioMsg11p msg);

    void receiveMsg(std::string receiver, veins::DemoSafetyMessage* msg);

    //todo
    void close(){ std::cout << "KafkaConnection todo: close()" << std::endl;};

    std::unique_ptr<veins::TraCICoordinateTransformation> coordinateTransformation;
    void setNetbounds(veins::TraCICoord netbounds1, veins::TraCICoord netbounds2, int margin);
    veins::Coord traci2omnet(veins::TraCICoord coord) const;
    std::list<veins::Coord> traci2omnet(const std::list<veins::TraCICoord>& list) const;
    veins::TraCICoord omnet2traci(veins::Coord coord) const;
    std::list<veins::TraCICoord> omnet2traci(const std::list<veins::Coord>& list) const;
    veins::Heading traci2omnetHeading(double heading) const;
    double omnet2traciHeading(veins::Heading heading) const;


    };
#endif
