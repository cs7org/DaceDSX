/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#ifndef OBSERVER_HH_1089802683__H_
#define OBSERVER_HH_1089802683__H_


#include <sstream>
#include "boost/any.hpp"
#include "avro/Specific.hh"
#include "avro/Encoder.hh"
#include "avro/Decoder.hh"

namespace c {
struct Observer {
    std::string Task;
    std::string Attribute;
    std::string Filter;
    std::string Subject;
    int32_t Period;
    std::string Trigger;
    Observer() :
        Task(std::string()),
        Attribute(std::string()),
        Filter(std::string()),
        Subject(std::string()),
        Period(int32_t()),
        Trigger(std::string())
        { }
};

}
namespace avro {
template<> struct codec_traits<c::Observer> {
    static void encode(Encoder& e, const c::Observer& v) {
        avro::encode(e, v.Task);
        avro::encode(e, v.Attribute);
        avro::encode(e, v.Filter);
        avro::encode(e, v.Subject);
        avro::encode(e, v.Period);
        avro::encode(e, v.Trigger);
    }
    static void decode(Decoder& d, c::Observer& v) {
        if (avro::ResolvingDecoder *rd =
            dynamic_cast<avro::ResolvingDecoder *>(&d)) {
            const std::vector<size_t> fo = rd->fieldOrder();
            for (std::vector<size_t>::const_iterator it = fo.begin();
                it != fo.end(); ++it) {
                switch (*it) {
                case 0:
                    avro::decode(d, v.Task);
                    break;
                case 1:
                    avro::decode(d, v.Attribute);
                    break;
                case 2:
                    avro::decode(d, v.Filter);
                    break;
                case 3:
                    avro::decode(d, v.Subject);
                    break;
                case 4:
                    avro::decode(d, v.Period);
                    break;
                case 5:
                    avro::decode(d, v.Trigger);
                    break;
                default:
                    break;
                }
            }
        } else {
            avro::decode(d, v.Task);
            avro::decode(d, v.Attribute);
            avro::decode(d, v.Filter);
            avro::decode(d, v.Subject);
            avro::decode(d, v.Period);
            avro::decode(d, v.Trigger);
        }
    }
};

}
#endif
