/*
 * Federate.cpp
 *
 *  Created on: 22.01.2018
 *      Author: guetlein
 */

#include "Decoders.h"
#include "Defines.h"

#include <avro/Decoder.hh>
#include <avro/Stream.hh>

Decoders* Decoders::inst = 0;

Decoders::Decoders(){}

Decoders* Decoders::getInstance(){
		if(inst == 0){
			inst = new Decoders();
			std::string errstr = "";
			Serdes::Conf *sconf = Serdes::Conf::create();

			/* Default URL */
			if (sconf->set("schema.registry.url", "http://localhost:8081", errstr))
				cout << "Conf failed: " << endl;

			/* Default framing to CP1 */
			if (sconf->set("deserializer.framing", "cp1", errstr))
				cout <<  "Conf failed: " << endl;


			inst->serdes = Serdes::Avro::create(sconf, errstr);

		}
		return inst;
	}
void Decoders::initSchema(std::vector<std::string> topics){
	string errstr = "";
	for(string t : topics){
		std::string schema_name = t+"-value";

		cout << "looking up for " << schema_name << endl;
		schemas[t] = Serdes::Schema::get(serdes, schema_name, errstr);


		if(schemas[t] == 0){
			cout << "nothing found for " << t << "! " << errstr<< endl;
			cout << "creating it "<< endl;

			if(t.find(TOPIC_SYNCMSG) != string::npos){
				string schema_def = "{\"type\":\"record\",\"name\":\"SyncMsg\",\"namespace\":\"eu.fau.cs7.datamodel\",\"fields\":[{\"name\":\"Sender\",\"type\":\"string\"},{\"name\":\"Action\",\"type\":\"string\"},{\"name\":\"Time\",\"type\":\"long\"},{\"name\":\"Messages\",\"type\":{\"type\":\"array\",\"items\":{\"type\":\"record\",\"name\":\"KeyValue\",\"fields\":[{\"name\":\"Key\",\"type\":\"string\"},{\"name\":\"Value\",\"type\":\"string\"}]}}}]}";
				schemas[t] = Serdes::Schema::add(serdes, schema_name,  schema_def, errstr);
			}
			else if(t.find(TOPIC_MICRO) != string::npos){
				string schema_def = "{\"type\":\"record\",\"name\":\"Micro\",\"namespace\":\"eu.fau.cs7.datamodel\",\"fields\":[{\"name\":\"vehicleID\",\"type\":\"string\"},{\"name\":\"acceleration\",\"type\":\"double\"},{\"name\":\"angle\",\"type\":\"double\"},{\"name\":\"edge\",\"type\":\"string\"},{\"name\":\"lane\",\"type\":\"int\"},{\"name\":\"positionX\",\"type\":\"double\"},{\"name\":\"positionY\",\"type\":\"double\"},{\"name\":\"positionZ\",\"type\":\"double\"},{\"name\":\"positionEdge\",\"type\":\"double\"},{\"name\":\"route\",\"type\":\"string\"},{\"name\":\"speed\",\"type\":\"double\"},{\"name\":\"vtype\",\"type\":\"string\"}]}";
				cout << "calling serdes.add" << endl;
				schemas[t] = Serdes::Schema::add(serdes, schema_name,  schema_def, errstr);
				cout << "seredes calldone" << endl;
			}
            else if(t.find(TOPIC_RESULT) != string::npos){
                string schema_def = "{\"type\":\"record\",\"name\":\"Result\",\"namespace\":\"eu.fau.cs7.datamodel\",\"fields\":[{\"name\":\"name\",\"type\":\"string\"},{\"name\":\"type\",\"type\":\"string\"},{\"name\":\"file\",\"type\":\"bytes\"}]}";
                schemas[t] = Serdes::Schema::add(serdes, schema_name,  schema_def, errstr);
            }
            else if(t.find(TOPIC_RECEIVEMSG) != string::npos){
                string schema_def = "{\"type\":\"record\",\"name\":\"RadioMsg11p\",\"namespace\":\"eu.fau.cs7.datamodel\",\"fields\":[{\"name\":\"Sender\",\"type\":\"string\"},{\"name\":\"Params\",\"type\":\"string\"},{\"name\":\"Type\",\"type\":\"string\"},{\"name\":\"Payload\",\"type\":\"string\"}]}";
                schemas[t] = Serdes::Schema::add(serdes, schema_name,  schema_def, errstr);
            }
			else{
				cout << "DECODERY ERRORS " << endl;
			}
		}else{
			cout << "db knows schema for " << t << endl;

			cout << "received: " << schemas[t]->id();
			cout << "received: " << schemas[t]->name();
			cout << "received: " << schemas[t]->definition();
		}


		cout << "initSchema " << t << ": " << schemas[t]->definition() << endl;
	}
}
std::vector<char> Decoders::encodeMicro (c::Micro& micro) {
	std::vector<char> out;
	std::string errstr;
	avro::ValidSchema *avro_schema = schemas[TOPIC_MICRO]->object();
	if(avro_schema == 0){
		cout << "schema is null" << endl;

	}

	cout << "schema is ready: " << schemas[TOPIC_MICRO]->definition() << endl;

	avro::EncoderPtr e = avro::validatingEncoder(*avro_schema,avro::binaryEncoder());
	std::auto_ptr<avro::OutputStream> bin_os = avro::memoryOutputStream();
	e->init(*bin_os.get());

	cout << "init" << endl;
	avro::encode(*e, micro);
	e->flush();

	cout << "flush" << endl;

	/* Extract written bytes. */
		boost::shared_ptr<std::vector<uint8_t> > v;
		v = avro::snapshot(*bin_os.get());
		/* Write framing */
		schemas[TOPIC_MICRO]->framing_write(out);

		cout << "framing" << endl;
		/* Write binary encoded Avro to output vector */
		out.insert(out.end(), v->begin(), v->end());


	return out;
}
std::vector<char> Decoders::encodeResourceFile (c::ResourceFile& rf) {
	std::vector<char> out;
	std::string errstr;
	avro::ValidSchema *avro_schema = schemas[TOPIC_RESULT]->object();
	if(avro_schema == 0){
		cout << "schema is null" << endl;
	}

	avro::EncoderPtr e = avro::validatingEncoder(*avro_schema,avro::binaryEncoder());
	std::auto_ptr<avro::OutputStream> bin_os = avro::memoryOutputStream();
	e->init(*bin_os.get());
	avro::encode(*e, rf);
	e->flush();

	/* Extract written bytes. */
		boost::shared_ptr<std::vector<uint8_t> > v;
		v = avro::snapshot(*bin_os.get());
		/* Write framing */
		schemas[TOPIC_RESULT]->framing_write(out);
		/* Write binary encoded Avro to output vector */
		out.insert(out.end(), v->begin(), v->end());


	return out;
}

std::vector<char> Decoders::encodeRadioMsg11p (c::RadioMsg11p msg) {

    std::vector<char> out;
    std::string errstr;

    cout << "retrieving schema pointer"<<endl;

    avro::ValidSchema *avro_schema = schemas[TOPIC_RECEIVEMSG]->object();

    if(avro_schema == 0){
        cout << "schema is null" << endl;
    }

    cout << "Receiver="<<msg.Sender<<endl;


    avro::EncoderPtr e = avro::validatingEncoder(*avro_schema,avro::binaryEncoder());
    std::auto_ptr<avro::OutputStream> outp = avro::memoryOutputStream();
    std::auto_ptr<avro::OutputStream> bin_os = avro::memoryOutputStream();
    e->init(*bin_os.get());
    avro::encode(*e, msg);
    e->flush();

    /* Extract written bytes. */
    boost::shared_ptr<std::vector<uint8_t> > v;
    v = avro::snapshot(*bin_os.get());
    /* Write framing */
    schemas[TOPIC_RECEIVEMSG]->framing_write(out);
    /* Write binary encoded Avro to output vector */
    out.insert(out.end(), v->begin(), v->end());

    return out;
}


std::vector<char> Decoders::encodeSyncMsg (string id, string action, long time, std::vector<c::KeyValue> messages) {

	std::vector<char> out;
	std::string errstr;

	cout << "retrieving schema pointer"<<endl;

	avro::ValidSchema *avro_schema = schemas[TOPIC_SYNCMSG]->object();

	if(avro_schema == 0){
		cout << "schema is null" << endl;
	}

	c::SyncMsg syncMsg;
	syncMsg.Sender = id;
	syncMsg.Time = time;
	syncMsg.Action = action;
	syncMsg.Messages = messages;

	cout << "id="<<syncMsg.Sender<<",time="<<syncMsg.Time<<endl;


	avro::EncoderPtr e = avro::validatingEncoder(*avro_schema,avro::binaryEncoder());
	std::auto_ptr<avro::OutputStream> outp = avro::memoryOutputStream();
	std::auto_ptr<avro::OutputStream> bin_os = avro::memoryOutputStream();
	e->init(*bin_os.get());
	avro::encode(*e, syncMsg);
	e->flush();

	/* Extract written bytes. */
	boost::shared_ptr<std::vector<uint8_t> > v;
	v = avro::snapshot(*bin_os.get());
	/* Write framing */
	schemas[TOPIC_SYNCMSG]->framing_write(out);
	/* Write binary encoded Avro to output vector */
	out.insert(out.end(), v->begin(), v->end());

	return out;
}

/**
 * Deserialize/decode a value and print it to stdout as JSON fields with
 * the given prefix
 */
//c::TAG Decoders::decodeTAG (const std::string &pfx, const void *buf, size_t len) {
//	std::string out;
//	avro::GenericDatum* d = NULL;
//	Serdes::Schema *schema = NULL;
//	std::string errstr;
//
//	serdes->deserialize(&schema, &d, buf, len, errstr);
//
//	c::TAG tag;
//	avro::GenericRecord r = d->value<avro::GenericRecord>();
//	tag.time = r.field("time").value<long>();
//
//	if (d)
//		delete d;
//
//	return tag;
//}
c::SyncMsg Decoders::decodeSyncMsg (const std::string &pfx, const void *buf, size_t len) {
	std::string out;
	avro::GenericDatum* d = NULL;
	Serdes::Schema *schema = NULL;
	std::string errstr;

	serdes->deserialize(&schema, &d, buf, len, errstr);

	c::SyncMsg syncMsg;
	avro::GenericRecord r = d->value<avro::GenericRecord>();
	syncMsg.Time = r.field("Time").value<long>();
	syncMsg.Action = r.field("Action").value<string>();
	syncMsg.Sender = r.field("Sender").value<string>();

	for(avro::GenericDatum rr : r.field("Messages").value<avro::GenericArray>().value()){
		avro::GenericRecord rl = rr.value<avro::GenericRecord>();
		c::KeyValue kv;
		kv.Key = rl.field("Key").value<string>();
		kv.Value = rl.field("Value").value<string>();
		syncMsg.Messages.push_back(kv);
	}

	if (d)
		delete d;

	return syncMsg;
}
//c::TAR Decoders::decodeTAR (const std::string &pfx, const void *buf, size_t len) {
//	std::string out;
//	avro::GenericDatum* d = NULL;
//	Serdes::Schema *schema = NULL;
//	std::string errstr;
//
//	serdes->deserialize(&schema, &d, buf, len, errstr);
//
//	c::TAR tar;
//	avro::GenericRecord r = d->value<avro::GenericRecord>();
//	tar.id = r.field("id").value<string>();
//	tar.time = r.field("time").value<long>();
//
//	if (d)
//		delete d;
//
//	return tar;
//}

 c::ResourceFile Decoders::decodeResourceFile (const std::string &pfx, const void *buf, size_t len) {
	std::string out;
	avro::GenericDatum* d = NULL;
	Serdes::Schema *schema = NULL;
	std::string errstr;

	serdes->deserialize(&schema, &d, buf, len, errstr);

	c::ResourceFile resourceFile;
	avro::GenericRecord r = d->value<avro::GenericRecord>();
	resourceFile.ID = r.field("ID").value<string>();
	resourceFile.Type = r.field("Type").value<string>();
	resourceFile.File = r.field("File").value< std::vector<uint8_t>>();

	if (d)
		delete d;

	return resourceFile;
}

c::Scenario Decoders::decodeScenario (const std::string &pfx, const void *buf, size_t len) {

	/* NOT WORKING 1
	std::auto_ptr<avro::InputStream> in = avro::memoryInputStream((const unsigned char*)buf, len);
	avro::DecoderPtr decoder = avro::binaryDecoder();
	decoder->init(*in);

	c::Scenario scenario;
	avro::decode(*decoder, scenario);
	cout << "succ" << endl;
	--> NOT WORKING
	Scenario_avsc_Union__0__   n=18446744073709551609
	terminate called after throwing an instance of 'avro::Exception'
	  what():  Union index too big
	Maybe without unions... */




	/* NOT WORKING 2
	avro::GenericDatum datum(schemas[TOPIC_SCENARIO]);
	avro::decode(*decoder, datum);
	cout << "succ" << endl;
	scenario = datum.value<c::Scenario>();
	cout << scenario.ID << endl; */






	//bugs: need to do this by hand :-(
	//bugs: need to do this by hand :-(
	//bugs: need to do this by hand :-(
	std::string out;
	avro::GenericDatum* d = NULL;
	Serdes::Schema *schema = NULL;
	std::string errstr;

	cout << "calling serdes " << endl;
	serdes->deserialize(&schema, &d, buf, len, errstr);

	cout << "building obj" << endl;

	c::Scenario scenario;
	avro::GenericRecord r = d->value<avro::GenericRecord>();
	avro::GenericRecord r2 = d->value<avro::GenericRecord>();
	scenario.ID = r.field("ID").value<string>();

	cout << "scenarioid=" << scenario.ID << endl;

	scenario.RoadMap = r.field("RoadMap").value<string>();
	cout << "RoadMap=" << scenario.RoadMap << endl;

	scenario.SimulationStart = r.field("SimulationStart").value<long>();
	cout << "SimulationStart=" << scenario.SimulationStart << endl;
	scenario.SimulationEnd = r.field("SimulationEnd").value<long>();
	cout << "SimulationEnd=" << scenario.SimulationEnd << endl;

	for(avro::GenericDatum rr : r.field("Inputs").value<avro::GenericArray>().value()){
		avro::GenericRecord rl = rr.value<avro::GenericRecord>();
		cout << "GenericRecord=" << endl;
		c::Input input;
		input.Layer = rl.field("Layer").value<string>();
		cout << "Layer=" << input.Layer << endl;
		input.Path = rl.field("Path").value<string>();
		input.Processing = rl.field("Processing").value<string>();
		scenario.Inputs.push_back(input);
	}


	cout << "Execution " << endl;
	//Segfault:
	//	c::Execution execution = r.field("Execution").value<c::Execution>();
	avro::GenericRecord aexecution =  r.field("Execution").value<avro::GenericRecord>();
	c::Execution execution;
	execution.Constraints = aexecution.field("Constraints").value<string>();
	execution.Priority = aexecution.field("Priority").value<long>();
	execution.RandomSeed = aexecution.field("RandomSeed").value<long>();
	execution.SyncedParticipants = aexecution.field("SyncedParticipants").value<long>();
	cout << "Execution SyncedParticipants=" << execution.SyncedParticipants << endl;

	scenario.Execution = execution;

	//optinal fields are handed with boost::any -> sim.LayerParams.get_array() instead of sim.LayerPArams

	for(avro::GenericDatum rr : r.field("TrafficSimulators").value<avro::GenericArray>().value()){
			cout << "TrafficSimulator" << endl;
			c::TrafficSimulator sim;
			avro::GenericRecord rl = rr.value<avro::GenericRecord>();
			sim.ID = rl.field("ID").value<string>();

			cout << "id=" << sim.ID << endl;

			sim.Type = rl.field("Type").value<string>();
			cout << "Type=" << sim.Type << endl;
			sim.StepLength = rl.field("StepLength").value<int>();
			cout << "StepLength=" << sim.StepLength << endl;
			sim.Layer = rl.field("Layer").value<string>();
			cout << "Layer=" << sim.Layer << endl;
			for(avro::GenericDatum rrr : rl.field("LayerParams").value<avro::GenericArray>().value()){
				avro::GenericRecord rrl = rrr.value<avro::GenericRecord>();
				c::KeyValue lp;
				lp.Key = rrl.field("Key").value<string>();
				cout << "Key=" << lp.Key << endl;
				lp.Value = rrl.field("Value").value<string>();
				sim.LayerParams.push_back(lp);
			}

			for(avro::GenericDatum rrr : rl.field("Results").value<avro::GenericArray>().value()){
				avro::GenericRecord rrl = rrr.value<avro::GenericRecord>();
				c::KeyValue lp;
				lp.Key = rrl.field("Key").value<string>();
				cout << "Key=" << lp.Key << endl;
				lp.Value = rrl.field("Value").value<string>();
				cout << "Value=" << lp.Value << endl;
				sim.Results.push_back(lp);
			}

			avro::GenericRecord atiming =  rl.field("Timing").value<avro::GenericRecord>();
			c::Timing timing;
			timing.Constrained = atiming.field("Constrained").value<bool>();
			cout << "Constrained=" << timing.Constrained << endl;
			timing.Lookahead = atiming.field("Lookahead").value<long>();
			cout << "Lookahead=" << timing.Lookahead << endl;
			timing.Regulating = atiming.field("Regulating").value<bool>();
			cout << "Regulating=" << timing.Regulating << endl;
			sim.Timing = timing;

			for(avro::GenericDatum rrr : rl.field("Responsibilities").value<avro::GenericArray>().value()){
				string resp = rrr.value<string>();
				cout << "resp" << resp << endl;
				sim.Responsibilities.push_back(resp);
			}
			for(avro::GenericDatum rrr : rl.field("Borders").value<avro::GenericArray>().value()){
				string border = rrr.value<string>();
				cout << "border" << border << endl;
				sim.Borders.push_back(border);
			}

			for(avro::GenericDatum rrr : rl.field("Observers").value<avro::GenericArray>().value()){
				c::Observer ob;
				avro::GenericRecord obr = rrr.value<avro::GenericRecord>();
				ob.Task = obr.field("Task").value<string>();
				cout << "Task=" << ob.Task << endl;
				ob.Attribute = obr.field("Attribute").value<string>();
				ob.Filter = obr.field("Filter").value<string>();
				ob.Subject = obr.field("Subject").value<string>();
				ob.Period = obr.field("Period").value<int32_t>();
				ob.Trigger = obr.field("Trigger").value<string>();
				sim.Observers.push_back(ob);
			}
			scenario.TrafficSimulators.push_back(sim);
		}

	for(avro::GenericDatum rr : r.field("Translators").value<avro::GenericArray>().value()){
		avro::GenericRecord rl = rr.value<avro::GenericRecord>();
		c::Translator translator;
		translator.ID = rl.field("ID").value<string>();
		translator.Domain = rl.field("Domain").value<string>();
		translator.InputLayer = rl.field("InputLayer").value<string>();
		translator.OutputLayer = rl.field("OutputLayer").value<string>();
		translator.CustomParams = rl.field("CustomParams").value<string>();
		scenario.Translators.push_back(translator);
	}

	for(avro::GenericDatum rr : r.field("AdditionalSimulators").value<avro::GenericArray>().value()){
			cout << "AdditionalSimulator" << endl;
			c::AdditionalSimulator sim;
			avro::GenericRecord rl = rr.value<avro::GenericRecord>();
			sim.ID = rl.field("ID").value<string>();

			cout << "id=" << sim.ID << endl;

			sim.Domain = rl.field("Domain").value<string>();
			cout << "Domain=" << sim.Domain << endl;
			sim.Type = rl.field("Type").value<string>();
			cout << "Type=" << sim.Type << endl;
			sim.StackOn = (rl.field("StackOn").value<string>());
			cout << "StackOn=" << sim.StackOn << endl;
			sim.Layer = rl.field("Layer").value<string>();
			cout << "Layer=" << sim.Layer << endl;
			for(avro::GenericDatum rrr : rl.field("LayerParams").value<avro::GenericArray>().value()){
				avro::GenericRecord rrl = rrr.value<avro::GenericRecord>();
				c::KeyValue lp;
				lp.Key = rrl.field("Key").value<string>();
				cout << "Type=" << sim.Type << endl;
				lp.Value = rrl.field("Value").value<string>();
				sim.LayerParams.push_back(lp);
			}

			for(avro::GenericDatum rrr : rl.field("Results").value<avro::GenericArray>().value()){
				avro::GenericRecord rrl = rrr.value<avro::GenericRecord>();
				c::KeyValue lp;
				lp.Key = rrl.field("Key").value<string>();
				cout << "Type=" << sim.Type << endl;
				lp.Value = rrl.field("Value").value<string>();
				sim.Results.push_back(lp);
			}

			avro::GenericRecord atiming =  rl.field("Timing").value<avro::GenericRecord>();
			c::Timing timing;
			timing.Constrained = atiming.field("Constrained").value<bool>();
			timing.Lookahead = atiming.field("Lookahead").value<long>();
			timing.Regulating = atiming.field("Regulating").value<bool>();

			sim.Timing = timing;
			scenario.AdditionalSimulators.push_back(sim);
		}

	if (d)
		delete d;

	return scenario;
}

c::Config Decoders::decodeConfig (const std::string &pfx, const void *buf, size_t len) {
	std::string out;
	avro::GenericDatum* d = NULL;
	Serdes::Schema *schema = NULL;
	std::string errstr;

	serdes->deserialize(&schema, &d, buf, len, errstr);

	c::Config config;
	avro::GenericRecord r = d->value<avro::GenericRecord>();
	config.name = r.field("name").value<std::string>();
	config.start = r.field("start").value<int>();
	config.end = r.field("end").value<int>();
	config.step = r.field("step").value<int>();

	if (d)
		delete d;

	return config;
}

c::Resp Decoders::decodeResp (const std::string &pfx, const void *buf, size_t len) {
	std::string out;
	avro::GenericDatum* d = NULL;
	Serdes::Schema *schema = NULL;
	std::string errstr;

	serdes->deserialize(&schema, &d, buf, len, errstr);

	c::Resp resp;
	avro::GenericRecord r = d->value<avro::GenericRecord>();
	resp.id = r.field("id").value<std::string>();

	cout << "decodeResp resp.id is " << resp.id << endl;

	//	avro::GenericArray ar = r.field("links").value<avro::GenericArray>();
	////	cout << "1111 ";
	//
	//	vector<avro::GenericDatum>& rrr = ar.value();
	//	cout << "22222 ";
	//	cout << "size of links: " << rrr.size() << endl;

	for(avro::GenericDatum rr : r.field("links").value<avro::GenericArray>().value()){
		//		c::Link link = rr.value<c::Link>();
		c::Link link;
		avro::GenericRecord rl = rr.value<avro::GenericRecord>();
		link.LinkID = rl.field("LinkID").value<std::string>();
		//		cout << link.LinkID << endl;
		resp.links.push_back(link);
	}
	for(avro::GenericDatum rr : r.field("borders").value<avro::GenericArray>().value()){
		c::Border border;
		avro::GenericRecord rl = rr.value<avro::GenericRecord>();
		border.LinkID = rl.field("LinkID").value<std::string>();
		resp.borders.push_back(border);
	}

	if (d)
		delete d;

	return resp;
}
c::Micro Decoders::decodeMicro (const std::string &pfx, const void *buf, size_t len) {
	std::string out;
	avro::GenericDatum* d = NULL;
	Serdes::Schema *schema = NULL;
	std::string errstr;

	serdes->deserialize(&schema, &d, buf, len, errstr);

	c::Micro micro;
	avro::GenericRecord r = d->value<avro::GenericRecord>();
	micro.vehicleID = r.field("vehicleID").value<std::string>();
	micro.route = r.field("route").value<std::string>();
	micro.lane = r.field("lane").value<int>();
	micro.positionX = r.field("positionX").value<double>();
	micro.positionY = r.field("positionY").value<double>();
	micro.positionZ = r.field("positionZ").value<double>();
	micro.positionEdge = r.field("positionEdge").value<double>();
	micro.speed = r.field("speed").value<double>();
	micro.acceleration = r.field("acceleration").value<double>();

	if (d)
		delete d;

	//  std::unique_ptr<avro::InputStream> in = avro::memoryInputStream(buf);
	//  avro::DecoderPtr d = avro::binaryDecoder();
	//  d->init(*in);
	//  c::Micro m;
	//  avro::decode(*d,m);

	return micro;
}
c::RadioMsg11p Decoders::decodeRadioMsg11p (const std::string &pfx, const void *buf, size_t len) {
    std::string out;
    avro::GenericDatum* d = NULL;
    Serdes::Schema *schema = NULL;
    std::string errstr;

    serdes->deserialize(&schema, &d, buf, len, errstr);

    c::RadioMsg11p msg;
    avro::GenericRecord r = d->value<avro::GenericRecord>();
    msg.Sender = r.field("Sender").value<std::string>();
    msg.Params = r.field("Params").value<std::string>();
    msg.Type = r.field("Type").value<std::string>();
    msg.Payload = r.field("Payload").value<std::string>();

    if (d)
        delete d;

    return msg;
}




