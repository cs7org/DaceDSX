#ifndef KafkaConsumer_H
#define KafkaConsumer_H

#include <stdexcept>
#include <iostream>
#include <csignal>
#include <thread>
#include "cppkafka/consumer.h"
#include "cppkafka/configuration.h"
#include "cppkafka/utils/consumer_dispatcher.h"

#include "KafkaConnection.h"

using std::string;
using std::exception;
using std::cout;
using std::endl;

using cppkafka::Consumer;
using cppkafka::ConsumerDispatcher;
using cppkafka::Configuration;
using cppkafka::Message;
using cppkafka::TopicPartition;
using cppkafka::TopicPartitionList;
using cppkafka::Error;


class KafkaConnection;


class KafkaConsumer{
	Consumer* consumer;
	volatile bool running = true;
	std::thread t1;
	KafkaConnection* callback;

public:
	KafkaConsumer(){};
	~KafkaConsumer(){delete consumer;};

	void subscribe(std::string broker, std::vector<std::string> topic, KafkaConnection* cb);

	void stop();
	void listen();
};

#endif
