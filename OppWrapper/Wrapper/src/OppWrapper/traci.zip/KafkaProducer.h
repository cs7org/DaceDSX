#ifndef KafkaProducer_H
#define KafkaProducer_H

#include <stdexcept>
#include <iostream>
#include <map>
#include "cppkafka/producer.h"
#include "cppkafka/configuration.h"

using std::string;
using std::exception;
using std::getline;
using std::cin;
using std::cout;
using std::endl;

using cppkafka::Producer;
using cppkafka::Configuration;
using cppkafka::Topic;
using cppkafka::MessageBuilder;

class KafkaProducer{
	Producer* producer;
	std::map<std::string, MessageBuilder*> msgBuilders;

	public:
	KafkaProducer(){};
	~KafkaProducer(){delete producer;};

	void init(std::string broker, std::vector<std::string> topics,string i);
	void publish(std::string topic, std::string key, std::string payload);
	void publish(std::string topic, std::string key, std::vector<char>& payload);
};
#endif
