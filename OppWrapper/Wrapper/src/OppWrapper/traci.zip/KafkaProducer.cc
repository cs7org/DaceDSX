#include "KafkaProducer.h"

void KafkaProducer::init(std::string brokers, std::vector<std::string> topics, string simid) {
	string group_id = simid;
    int partition_value = -1;


	for(std::string t : topics){
		cout << "Adding msgbuilder for " << t << endl;
		msgBuilders[t] = new MessageBuilder(t);

		// Get the partition we want to write to. If no partition is provided, this will be
	    // an unassigned one
	    if (partition_value != -1) {
	    	msgBuilders[t]->partition(partition_value);
	    }
	}

	    // Construct the configuration
	    Configuration config = {
		        { "metadata.broker.list", brokers },
		        { "enable.idempotence", true }
	    };

	    // Create the producer
	    producer = new Producer(config);


		cout << "created builders and producer " << endl;
}


void KafkaProducer::publish(std::string topic, std::string key, std::string payload){

	cout << "publishing " << payload << " to " << topic << endl;
	try{
//		int subtopic =  topic.find(".", topic.find("."));
//		string buildertopic = topic;
//		if(subtopic != string::npos)
//			string buildertopic = topic.substr(0,subtopic);

		MessageBuilder* b = msgBuilders[topic];
		if(b==NULL){
			cout << "No builder for " << topic << ", skipping! " << endl;
			return;
//			cout << "No builder for " << buildertopic << ", using first builder " << endl;
//			b = msgBuilders.begin()->second;
		}
		b->key(key);
		b->payload(payload);
		producer->produce(*b);

		// Flush all produced messages
		producer->flush();

	}catch(cppkafka::HandleException& e){
		cout << "Error in publish()" << endl;
		cout << e.what() << endl;
	}
}

void KafkaProducer::publish(std::string topic, std::string key, std::vector<char>& payload){

	cout << "publishing " << payload[0] << " to " << topic << endl;


	try{
		MessageBuilder* b = msgBuilders[topic];
		if(b==NULL){
			cout << "No builder for " << topic << ", skipping! " << endl;
			return;
		}
		b->key(key);
		b->payload(payload);
		producer->produce(*b);

		// Flush all produced messages
		producer->flush();
	}catch(cppkafka::HandleException& e){
		cout << "Error in publish()" << endl;
		cout << e.what() << endl;
	}
}

