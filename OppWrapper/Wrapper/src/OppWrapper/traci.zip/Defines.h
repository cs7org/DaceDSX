#define CHANNEL_PROVISION "provision"
#define CHANNEL_INTERACTION "interaction"
#define CHANNEL_ORCHESTRATION "orchestration"

#define TOPIC_RESOURCE "resource"
#define TOPIC_SCENARIO "scenario"
#define TOPIC_RESULT "result"

#define TOPIC_MICRO "micro"
#define TOPIC_SYNCMSG "sync"
#define TOPIC_SENDMSG "communication.send"
#define TOPIC_RECEIVEMSG "communication.receive"

//#include <string>
//const std::string CHANNEL_PROVISION = "provision";
//const std::string  CHANNEL_INTERACTION= "interaction";
//const std::string  CHANNEL_ORCHESTRATION ="orchestration";
//
//const std::string  TOPIC_RESOURCE ="resource";
//const std::string  TOPIC_SCENARIO= "scenario";
//
//const std::string  TOPIC_TAG ="tag";
//const std::string  TOPIC_TAR ="tar";
//
//const std::string  TOPIC_MICRO= "micro";
