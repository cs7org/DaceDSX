/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#ifndef ADDITIONALSIMULATOR_HH_3930442827__H_
#define ADDITIONALSIMULATOR_HH_3930442827__H_


#include <sstream>
#include "boost/any.hpp"
#include "avro/Specific.hh"
#include "avro/Encoder.hh"
#include "avro/Decoder.hh"
#include "KeyValue.hh"
#include "Timing.hh"

namespace c {
struct AdditionalSimulator {
	std::string ID;
    std::string Type;
    std::string Domain;
    std::string Layer;
    std::vector<KeyValue> LayerParams;
    std::vector<KeyValue > Results;
    std::string StackOn;
    c::Timing Timing;
    std::string CustomParams;
    AdditionalSimulator() :
        ID(std::string()),
        Type(std::string()),
		Domain(std::string()),
        Layer(std::string()),
        LayerParams(std::vector<KeyValue>()),
		Results(std::vector<KeyValue>()),
        StackOn(std::string()),
        Timing(c::Timing()),
        CustomParams(std::string())
        { }
};

}
namespace avro {
template<> struct codec_traits<c::AdditionalSimulator> {
    static void encode(Encoder& e, const c::AdditionalSimulator& v) {
        avro::encode(e, v.ID);
        avro::encode(e, v.Type);
        avro::encode(e, v.Domain);
        avro::encode(e, v.Layer);
        avro::encode(e, v.LayerParams);
        avro::encode(e, v.Results);
        avro::encode(e, v.StackOn);
        avro::encode(e, v.Timing);
        avro::encode(e, v.CustomParams);
    }
    static void decode(Decoder& d, c::AdditionalSimulator& v) {
        if (avro::ResolvingDecoder *rd =
            dynamic_cast<avro::ResolvingDecoder *>(&d)) {
            const std::vector<size_t> fo = rd->fieldOrder();
            for (std::vector<size_t>::const_iterator it = fo.begin();
                it != fo.end(); ++it) {
                switch (*it) {
                case 0:
                    avro::decode(d, v.ID);
                    break;
                case 1:
                    avro::decode(d, v.Type);
                    break;
                case 2:
                    avro::decode(d, v.Domain);
                    break;
                case 3:
                    avro::decode(d, v.Layer);
                    break;
                case 4:
                    avro::decode(d, v.LayerParams);
                    break;
                case 5:
                    avro::decode(d, v.Results);
                    break;
                case 6:
                    avro::decode(d, v.StackOn);
                    break;
                case 7:
                    avro::decode(d, v.Timing);
                    break;
                case 8:
                    avro::decode(d, v.CustomParams);
                    break;
                default:
                    break;
                }
            }
        } else {
            avro::decode(d, v.ID);
            avro::decode(d, v.Type);
            avro::decode(d, v.Domain);
            avro::decode(d, v.Layer);
            avro::decode(d, v.LayerParams);
            avro::decode(d, v.Results);
            avro::decode(d, v.StackOn);
            avro::decode(d, v.Timing);
            avro::decode(d, v.CustomParams);
        }
    }
};

}
#endif
