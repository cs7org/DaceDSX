/*
 * KafkaConnection.cpp
 *
 *  Created on: Mar 16, 2020
 *      Author: guetlein
 */


#include "KafkaConnection.h"


KafkaConnection* KafkaConnection::inst = 0;

KafkaConnection* KafkaConnection::getInstance(std::string scenarioID){
    if(inst == 0){
        inst = new KafkaConnection(scenarioID);
    }
    return inst;
}

KafkaConnection* KafkaConnection::getInstance(){
    if(inst == 0){
        cout << "error!!!!!! KafkaConnection::getInstance() called before KafkaConnection::getInstance(SCENARIOID)" << endl;
        return 0;
    }
    return inst;
}

void KafkaConnection::init(){
    ////////////////////////
    //init Decocder, NEEDED for SENDING
    Decoders::getInstance()->initSchema({TOPIC_SYNCMSG, TOPIC_MICRO, TOPIC_RESULT, TOPIC_RECEIVEMSG});

    //////////////////////////////////////
    //init Producer
    producer = new KafkaProducer();
    //which topic will we publish to?
    std::vector<std::string> ptopics = {getTopic(CHANNEL_ORCHESTRATION, TOPIC_SYNCMSG),getTopic(CHANNEL_INTERACTION, TOPIC_RECEIVEMSG)};
    producer->init(host, ptopics,"omnetID");

    //////////////////////////////////////
    //init Producer
    consumer = new KafkaConsumer();
    //handling needs to be defined in consumer.cpp and redirected to this class (handleTopicXXX)
    consumer->subscribe(host, {getTopic(CHANNEL_ORCHESTRATION, TOPIC_SYNCMSG),getTopic(CHANNEL_PROVISION, "vehicle.micro"),getTopic(CHANNEL_INTERACTION, TOPIC_SENDMSG)}, this );

    join();
}

void KafkaConnection::join(){

    std::vector<c::KeyValue> kvs;
    cout << "KafkaConnection::join calling encodeSyncMsg " << endl;
    vector<char> out = Decoders::getInstance()->encodeSyncMsg("omnet", "request", 0L, kvs);
    cout << "KafkaConnection:: decoded" << endl;
    producer->publish(getTopic(CHANNEL_ORCHESTRATION, TOPIC_SYNCMSG), "join", out);

    cout << "KafkaConnection:: waiting for start " << endl;
    while (kafkaTime < 0){
        usleep(1000*1000);
        producer->publish(getTopic(CHANNEL_ORCHESTRATION, TOPIC_SYNCMSG), "join", out);
        cout << "KafkaConnection:: still waitinging for start, kafkatime="<<kafkaTime << endl;
    }

    cout << "KafkaConnection:: init tag received" << endl;
}
void KafkaConnection::timeAdvance(long newkafkatime){

    std::vector<c::KeyValue> kvs;
    vector<char> out = Decoders::getInstance()->encodeSyncMsg("omnet", "request", newkafkatime, kvs);

    producer->publish(getTopic(CHANNEL_ORCHESTRATION, TOPIC_SYNCMSG), "tar", out);

    cout << "sending tar to " << newkafkatime << endl;
    int counter = 1;
    while (kafkaTime < newkafkatime){
        usleep(1000*10);
        if (counter++ % 1000 == 0)
            cout << "waiting for tag to " << newkafkatime << ", currently at " << kafkaTime << endl;
    }

    cout << "gottag for " << newkafkatime << endl;
}

std::string KafkaConnection::getTopic(string channel, string topic){
    return channel+"."+scenarioID+"."+topic;
}

void KafkaConnection::handleTopicMicro(std::string key, c::Micro micro){
    unreadSubscribtions.push_back(micro);
}

void KafkaConnection::handleTopicSyncMsg(std::string key, c::SyncMsg syncMsg){
    if(syncMsg.Time >kafkaTime){
        kafkaTime = syncMsg.Time;
        cout << "kafkatime is now: " << kafkaTime << endl;
    }
    else{
        cout << "++++++ ignoring MSG counts +++++++++++++ kafkatime is: " << kafkaTime <<",  tag.time: " << syncMsg.Time<< endl;
    }
}

void KafkaConnection::handleTopicSendRadioMsg11p(std::string key, c::RadioMsg11p msg){
    //todo:: in this whole mode updates only per step
    cout << "unreadsendMsgRequests.push_back(msg) from sender=" << msg.Sender << endl;
    unreadsendMsgRequests.push_back(msg);
}

void KafkaConnection::receiveMsg(std::string receiver, veins::DemoSafetyMessage* bsm){

    c::RadioMsg11p msg;
    msg.Sender = receiver;
    msg.Type = "BSM";
//    msg.Payload = bsm->getEncapsulatedPacket()->str();
    msg.Payload = bsm->str();
    vector<char> out = Decoders::getInstance()->encodeRadioMsg11p(msg);
    producer->publish(getTopic(CHANNEL_INTERACTION, TOPIC_RECEIVEMSG), "tar", out);
}



void KafkaConnection::setNetbounds(veins::TraCICoord netbounds1, veins::TraCICoord netbounds2, int margin)
{
    coordinateTransformation.reset(new veins::TraCICoordinateTransformation(netbounds1, netbounds2, margin));
}

veins::Coord KafkaConnection::traci2omnet(veins::TraCICoord coord) const
{
    ASSERT(coordinateTransformation.get());
    return coordinateTransformation->traci2omnet(coord);
}

std::list<veins::Coord> KafkaConnection::traci2omnet(const std::list<veins::TraCICoord>& list) const
{
    ASSERT(coordinateTransformation.get());
    return coordinateTransformation->traci2omnet(list);
}

veins::TraCICoord KafkaConnection::omnet2traci(veins::Coord coord) const
{
    ASSERT(coordinateTransformation.get());
    return coordinateTransformation->omnet2traci(coord);
}

std::list<veins::TraCICoord> KafkaConnection::omnet2traci(const std::list<veins::Coord>& list) const
{
    ASSERT(coordinateTransformation.get());
    return coordinateTransformation->omnet2traci(list);
}

veins::Heading KafkaConnection::traci2omnetHeading(double heading) const
{
    ASSERT(coordinateTransformation.get());
    return coordinateTransformation->traci2omnetHeading(heading);
}

double KafkaConnection::omnet2traciHeading(veins::Heading heading) const
{
    ASSERT(coordinateTransformation.get());
    return coordinateTransformation->omnet2traciHeading(heading);
}
