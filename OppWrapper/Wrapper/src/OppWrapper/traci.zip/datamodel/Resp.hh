/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#ifndef _HOME_GUETLEIN_SVN_GUETLEIN_SUMOFEDERATEWRAPPER_RESP_HH_4010491960__H_
#define _HOME_GUETLEIN_SVN_GUETLEIN_SUMOFEDERATEWRAPPER_RESP_HH_4010491960__H_


#include <sstream>
#include "boost/any.hpp"
#include "avro/Specific.hh"
#include "avro/Encoder.hh"
#include "avro/Decoder.hh"

namespace c {
struct Link {
    std::string LinkID;
    Link() :
        LinkID(std::string())
        { }
};

struct Border {
    std::string LinkID;
    Border() :
        LinkID(std::string())
        { }
};

struct Resp {
    std::string id;
    std::vector<Link > links;
    std::vector<Border > borders;
    Resp() :
        id(std::string()),
        links(std::vector<Link >()),
        borders(std::vector<Border >())
        { }
};

}
namespace avro {
template<> struct codec_traits<c::Link> {
    static void encode(Encoder& e, const c::Link& v) {
        avro::encode(e, v.LinkID);
    }
    static void decode(Decoder& d, c::Link& v) {
        if (avro::ResolvingDecoder *rd =
            dynamic_cast<avro::ResolvingDecoder *>(&d)) {
            const std::vector<size_t> fo = rd->fieldOrder();
            for (std::vector<size_t>::const_iterator it = fo.begin();
                it != fo.end(); ++it) {
                switch (*it) {
                case 0:
                    avro::decode(d, v.LinkID);
                    break;
                default:
                    break;
                }
            }
        } else {
            avro::decode(d, v.LinkID);
        }
    }
};

template<> struct codec_traits<c::Border> {
    static void encode(Encoder& e, const c::Border& v) {
        avro::encode(e, v.LinkID);
    }
    static void decode(Decoder& d, c::Border& v) {
        if (avro::ResolvingDecoder *rd =
            dynamic_cast<avro::ResolvingDecoder *>(&d)) {
            const std::vector<size_t> fo = rd->fieldOrder();
            for (std::vector<size_t>::const_iterator it = fo.begin();
                it != fo.end(); ++it) {
                switch (*it) {
                case 0:
                    avro::decode(d, v.LinkID);
                    break;
                default:
                    break;
                }
            }
        } else {
            avro::decode(d, v.LinkID);
        }
    }
};

template<> struct codec_traits<c::Resp> {
    static void encode(Encoder& e, const c::Resp& v) {
        avro::encode(e, v.id);
        avro::encode(e, v.links);
        avro::encode(e, v.borders);
    }
    static void decode(Decoder& d, c::Resp& v) {
        if (avro::ResolvingDecoder *rd =
            dynamic_cast<avro::ResolvingDecoder *>(&d)) {
            const std::vector<size_t> fo = rd->fieldOrder();
            for (std::vector<size_t>::const_iterator it = fo.begin();
                it != fo.end(); ++it) {
                switch (*it) {
                case 0:
                    avro::decode(d, v.id);
                    break;
                case 1:
                    avro::decode(d, v.links);
                    break;
                case 2:
                    avro::decode(d, v.borders);
                    break;
                default:
                    break;
                }
            }
        } else {
            avro::decode(d, v.id);
            avro::decode(d, v.links);
            avro::decode(d, v.borders);
        }
    }
};

}
#endif
