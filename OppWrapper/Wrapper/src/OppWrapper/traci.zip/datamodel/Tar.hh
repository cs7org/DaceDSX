/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#ifndef _HOME_GUETLEIN_SVN_GUETLEIN_SUMOFEDERATEWRAPPER_TAR_HH_1744155158__H_
#define _HOME_GUETLEIN_SVN_GUETLEIN_SUMOFEDERATEWRAPPER_TAR_HH_1744155158__H_


#include <sstream>
#include "boost/any.hpp"
#include "avro/Specific.hh"
#include "avro/Encoder.hh"
#include "avro/Decoder.hh"

namespace c {
struct TAR {
    std::string id;
    int64_t time;
    TAR() :
        id(std::string()),
        time(int64_t())
        { }
};

}
namespace avro {
template<> struct codec_traits<c::TAR> {
    static void encode(Encoder& e, const c::TAR& v) {
        avro::encode(e, v.id);
        avro::encode(e, v.time);
    }
    static void decode(Decoder& d, c::TAR& v) {
        if (avro::ResolvingDecoder *rd =
            dynamic_cast<avro::ResolvingDecoder *>(&d)) {
            const std::vector<size_t> fo = rd->fieldOrder();
            for (std::vector<size_t>::const_iterator it = fo.begin();
                it != fo.end(); ++it) {
                switch (*it) {
                case 0:
                    avro::decode(d, v.id);
                    break;
                case 1:
                    avro::decode(d, v.time);
                    break;
                default:
                    break;
                }
            }
        } else {
            avro::decode(d, v.id);
            avro::decode(d, v.time);
        }
    }
};

}
#endif
